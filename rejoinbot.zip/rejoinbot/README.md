# RejoinBot 🔄

A self-hosted Discord bot that **automatically re-adds members who leave** — using Discord's official OAuth2 `guilds.join` API. Members authorize the bot once; if they ever leave (rage-quit, accidental leave, etc.), the bot pulls them back in seconds.

Also includes welcome/goodbye messages, a verification button panel, and basic moderation (`/ban`, `/kick`, `/timeout`).

> ⚠️ **Force-rejoin only works for users who explicitly authorize the bot via OAuth.** This is enforced by Discord's API — there is no workaround. Anyone claiming otherwise is using a selfbot, which will get accounts permanently banned. This bot does it the *correct, ToS-compliant* way.

---

## Features

- 🔄 **Force-Rejoin** — OAuth2 `guilds.join`, auto refresh, anti-loop, audit-log safety
- 👋 **Welcome / Goodbye** — channel + customizable templates (`{user}`, `{server}`, `{memberCount}`)
- 🔒 **Verification panel** — `/verify panel` posts a button that links to OAuth flow
- 🛠 **Moderation** — `/ban`, `/kick`, `/timeout` with reason logging
- 🐘 **PostgreSQL** — durable, scalable storage
- 🐳 **Docker + Railway + Render** ready out of the box

---

## Slash Commands

| Command | Description |
|---|---|
| `/forcerejoin enable` / `disable` / `status` | Toggle the feature per guild |
| `/forcerejoin link` | Get the OAuth link to share with members |
| `/forcerejoin exclude-user @user` | Skip a specific user |
| `/forcerejoin exclude-role @role` | Skip members with this role (e.g. ex-mods) |
| `/welcome set-welcome #channel [message]` | Enable welcome messages |
| `/welcome set-goodbye #channel [message]` | Enable goodbye messages |
| `/welcome status` / `disable-welcome` / `disable-goodbye` | |
| `/verify panel #channel` | Post the verification button |
| `/verify set-role @role` | Role to give once verified |
| `/ban @user [reason] [delete-days]` | Ban a member |
| `/kick @user [reason]` | Kick a member |
| `/timeout @user <minutes> [reason]` | Timeout (0 to remove) |

---

## Setup (Local Development)

### 1. Clone & install
```bash
git clone https://github.com/YOUR_USERNAME/rejoinbot.git
cd rejoinbot
npm install
```

### 2. Discord Developer Portal
1. https://discord.com/developers/applications → **New Application**
2. **Bot** tab → Reset Token → save it
3. Enable **SERVER MEMBERS INTENT** (required!)
4. **OAuth2** tab → copy **Client ID** and **Client Secret**
5. **OAuth2 → Redirects** → add: `http://localhost:3000/oauth/callback` (or your tunnel URL)
6. **OAuth2 → URL Generator** → check `bot` and `applications.commands` → permissions `Administrator` (for testing). Open the URL → invite the bot to a test server.

### 3. PostgreSQL
Either run locally:
```bash
docker run -d --name rejoinbot-pg -e POSTGRES_PASSWORD=secret -p 5432:5432 postgres:16
```
or use any hosted Postgres (Neon, Supabase, Railway, Render).

### 4. Configure
```bash
cp .env.example .env
# fill in DISCORD_TOKEN, CLIENT_ID, CLIENT_SECRET, OAUTH_REDIRECT_URI, PUBLIC_URL, DATABASE_URL
```

For local OAuth callback you'll need a public URL — use [ngrok](https://ngrok.com/):
```bash
ngrok http 3000
# Then set OAUTH_REDIRECT_URI and PUBLIC_URL to the https://....ngrok-free.app URL
```

### 5. Deploy slash commands & start
```bash
npm run deploy:commands
npm start
```

---

## Deploy to Production

### Option A — Railway (one-click)
1. Push this repo to GitHub.
2. https://railway.app → **New Project** → **Deploy from GitHub repo**.
3. Add a **PostgreSQL** plugin from the dashboard.
4. Set env vars from `.env.example` (Railway injects `DATABASE_URL` automatically).
5. After deploy, copy your `*.up.railway.app` URL and:
   - Set `PUBLIC_URL` and `OAUTH_REDIRECT_URI` in env
   - Add it to Dev Portal → OAuth2 → Redirects
6. Restart, then `npm run deploy:commands` once locally to register slash commands.

### Option B — Render (blueprint)
1. Push to GitHub.
2. https://render.com → **New → Blueprint** → point at this repo.
3. The included `render.yaml` provisions the web service + Postgres automatically.
4. Fill in the marked secrets, then deploy.

### Option C — Docker (any host)
```bash
docker build -t rejoinbot .
docker run -d --env-file .env -p 3000:3000 rejoinbot
```

---

## How Force-Rejoin works

```
First time (one-time consent):
  Member clicks /oauth/start?guild=...
    → Discord shows consent screen (Add you to servers)
    → /oauth/callback receives code
    → bot exchanges for access_token + refresh_token
    → stored in Postgres (oauth_tokens table)

When they leave:
  guildMemberRemove event fires
    → check guild config + anti-loop counters
    → check audit log (skip if banned/kicked)
    → refresh access_token if expired
    → PUT /guilds/{id}/members/{user.id}
    → ✅ user re-added with their original nickname
```

## Safety guards built-in

| Guard | Why |
|---|---|
| Audit log check | Don't fight mod actions (ban/kick) |
| `excluded_user_ids` | Manually skip specific users |
| `excluded_role_ids` | Skip members who had certain roles |
| `max_rejoins_per_day` (default 3) | Anti-loop protection |
| `rejoin_cooldown_ms` (default 5s) | Let Discord settle between attempts |
| 401/403 → delete tokens | Stop hammering revoked tokens |
| Privileged intent required | Won't silently fail without setup |

---

## License
MIT
