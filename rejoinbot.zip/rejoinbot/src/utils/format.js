// Replaces placeholders in welcome/goodbye message templates.
//   {user}        -> <@id> mention
//   {user.tag}    -> name#disc
//   {user.name}   -> username
//   {server}      -> guild name
//   {memberCount} -> current member count

export function formatMessage(template, member) {
  if (!template) return '';
  return template
    .replaceAll('{user.tag}', member.user.tag)
    .replaceAll('{user.name}', member.user.username)
    .replaceAll('{user}', `<@${member.user.id}>`)
    .replaceAll('{server}', member.guild.name)
    .replaceAll('{memberCount}', String(member.guild.memberCount));
}
